/*! angular-bootstrap-plus - v0.6.1 - 2016-08-18
* https://github.com/jrief/angular-bootstrap-plus
* Copyright (c) 2016 Jacob Rief; Licensed MIT */
