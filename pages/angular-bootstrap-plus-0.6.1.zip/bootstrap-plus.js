/**
 * angular-bootstrap-plus
 * @version v0.6.1 - 2016-08-21
 * @link https://github.com/jrief/angular-bootstrap-plus
 * @author Jacob Rief (jacob.rief@gmail.com)
 * @license MIT License, http://www.opensource.org/licenses/MIT
 */
(function(window, document, undefined) {
'use strict';
// Source: magnifier.js
(function() {
angular.module('bs-plus.magnifier', [])
.directive('bspMagnify', function() {
	return {
		restrict: 'EA',
		scope: {
			imageSrc: '@'
		},
		template: '<img src="{{ imageSrc }}" class="{{ cssClass }}" />' +
		          '<div class="{{ cssClass }}"><span></span></div>',
		link: function(scope, element, attrs) {
			var canvasElem = element.find('div');
			var plateElem = canvasElem.find('span');
			var magnify;
			scope.cssClass = attrs['class'];
			element.css({
				position: 'relative',
				'max-width': '100%',
				height: 'auto',
				display: 'inline-block'
			}).removeClass(scope.cssClass);
			canvasElem.css({
				opacity: 0,
				position: 'absolute',
				top: 0, right: 0, bottom: 0, left: 0,
				overflow: 'hidden',
				cursor: 'crosshair'
			});
			plateElem.css({
				width: '100%',
				height: '100%',
				display: 'inline-block'
			});
			canvasElem.on('mouseenter', function() {
				var imageElem = element.find('img');
				canvasElem.css('opacity', 1);
				plateElem.css('background-image', 'url("' + scope.imageSrc + '")');
				magnify = {
					byX: (imageElem[0].naturalWidth - imageElem[0].clientWidth) / imageElem[0].clientWidth,
					byY: (imageElem[0].naturalHeight - imageElem[0].clientHeight) / imageElem[0].clientHeight
				};
			});
			plateElem.on('mousemove', function(evt) {
				var posX = -evt.offsetX * magnify.byX;
				var posY = -evt.offsetY * magnify.byY;
				plateElem.css('background-position', posX + 'px ' + posY + 'px');
			}).on('mouseout', function () {
				canvasElem.css('opacity', 0);
			});
		}
	};
});

})();

// Source: processbar.js
(function() {
var module = angular.module('bs-plus.processbar', []);

module.directive('bspProcessBar', ['$compile', '$templateCache', function($compile, $templateCache) {
	return {
		restrict: 'E',
		scope: true,
		require: 'bspProcessBar',
		controller: ["$scope", function($scope) {
			var self = this;

			$scope.selectStep = function(step) {
				if (step.enabled) {
					$scope.activeStep = step;
					self.hideStepElements();
				}
			};

			$scope.stepButtonClass = function(step) {
				var classes = [];
				if (step.enabled && step.validated) {
					classes.push('btn-primary');
				} else {
					classes.push('btn-default');
				}
				if ($scope.activeStep === step) {
					classes.push('active');
				}
				return classes;
			};

			$scope.stepButtonDisabled = function(step) {
				return ($scope.activeStep !== step && !step.enabled);
			};

			this.hideStepElements = function() {
				var k, step;
				for (k = 0; k < $scope.bspProcessSteps.length; k++) {
					step = $scope.bspProcessSteps[k];
					if (step === $scope.activeStep) {
						step.element.removeClass('ng-hide');
					} else {
						step.element.addClass('ng-hide');
					}
				}
			};

			this.enableStepElements = function() {
				var k, enabled = true, step;
				for (k = 0; k < $scope.bspProcessSteps.length; k++) {
					step = $scope.bspProcessSteps[k];
					step.enabled = enabled;
					enabled = enabled && step.validated;
				}
			};
		}],
		link: {
			pre: function(scope, element, attrs) {
				// keep the validation state of each child form of this element
				scope.bspProcessSteps = [];
			},
			post: function(scope, element, attrs, controller) {
				var k, step;
				// add the process bar just below <bsp-process-bar>
				$compile($templateCache.get('bsp/process-bar.html'))(scope, function(clonedElement, scope) {
					element.prepend(clonedElement);
				});
				scope.activeStep = scope.bspProcessSteps[0];
				for (k = 0; k < scope.bspProcessSteps.length; k++) {
					step = scope.bspProcessSteps[k];
					if (step.validated) {
						scope.activeStep = step;
					}
				}
				controller.enableStepElements();
				controller.hideStepElements();
			}
		}
	};
}]);


module.directive('bspProcessStep', ['$q', function($q) {
	return {
		restrict: 'E',
		require: ['^bspProcessBar', 'bspProcessStep'],
		scope: true,
		controller: ["$scope", function($scope) {
			// check each child form's validation and reduce it to one single state
			var self = this;

			this.findProcessStep = function($id) {
				for (var k = 0; k < $scope.$parent.bspProcessSteps.length; k++) {
					if ($scope.$parent.bspProcessSteps[k].$id == $id)
						return $scope.$parent.bspProcessSteps[k];
				}
				throw new Error("Process step with $id=" + $id + " does not exist");
			};

			this.reduceValidation = function(formId, formIsValid) {
				$scope.bspValidatedForms[formId] = formIsValid;
				$scope.stepIsValid = true;
				angular.forEach($scope.bspValidatedForms, function(validatedForm) {
					$scope.stepIsValid = $scope.stepIsValid && validatedForm;
				});
				self.findProcessStep($scope.$id).validated = $scope.stepIsValid;
			};
		}],
		link: {
			pre: function(scope, element, attrs, controllers) {
				// to start with, add any value to the validation list
				scope.$parent.bspProcessSteps.push({
					$id: scope.$id,
					validated: false,
					title: attrs.title,
					element: element,
					enabled: false
				});
				// a map of booleans keeping the validation state for each of the child forms
				scope.bspValidatedForms = {};
			},
			post: function(scope, element, attrs, controllers) {
				scope.nextStep = function(promise) {
					var k;
					for (k = 0; k < scope.bspProcessSteps.length; k++) {
						if (scope.bspProcessSteps[k] === scope.$parent.activeStep)
							break;
					}
					$q.when(promise).then(function(result) {
						if (k < scope.$parent.bspProcessSteps.length - 1) {
							scope.$parent.activeStep = scope.$parent.bspProcessSteps[k + 1];
							controllers[0].enableStepElements();
							controllers[0].hideStepElements();
						}
					}, function(error) {
						console.error(error);
					});
				};
			}
		}
	};
}]);


module.directive('form', ['$timeout', function($timeout) {
	function toBoolean(value) {
		var v;
		if (value && value.length !== 0) {
			v = angular.lowercase("" + value);
			value = !(v == 'f' || v == '0' || v == 'false' || v == 'no' || v == 'n' || v == '[]');
		} else {
			value = false;
		}
		return value;
	}

	return {
		restrict: 'E',
		require: ['^?bspProcessStep', 'form'],
		priority: 1,
		scope: {},
		link: function(scope, element, attrs, controllers) {
			if (!controllers[0])
				return;  // not for forms outside a <bsp-process-step></bsp-process-step>

			element.find('input').on('keyup change', function() {
				// delay until validation is ready
				$timeout(reduceValidation);
			});
			element.find('select').on('change', function() {
				$timeout(reduceValidation);
			});
			element.find('textarea').on('blur', function() {
				$timeout(reduceValidation);
			});

			// delay first evaluation until form is fully validated
			$timeout(reduceValidation);

			function reduceValidation() {
				controllers[0].reduceValidation(scope.$id, controllers[1].$valid);
			}
		}
	};
}]);

})();

// Source: scrollpanel.js
(function() {
var module = angular.module('bs-plus.scrollpanel', []);

module.directive('bspScrollpanel', ['$timeout', '$window', function($timeout, $window) {
	return {
		transclude: true,
		templateUrl: 'scrollpanel/bsp-scrollpanel.tmpl.html',
		link: function(scope, element, attrs) {
			var child, delta, maxOffset, offset, initial, margin;

			function setDefaults() {
				maxOffset = child.scrollWidth - child.offsetWidth;
				offset = maxOffset * initial;
				delta = child.offsetWidth / 3;
				$timeout(setOffset, 250);
			}

			function setOffset() {
				offset = Number.isNaN(offset) ? -margin : Math.min(Math.max(offset, -margin), maxOffset);
				angular.element(child).css('margin-left', -offset + 'px');
			}

			child = element.children('ng-transclude').children();
			if (child.length > 3)
				throw new Error("A 'bsp-scrollpanel' directive may contain only one element");
			child = child[1];
			initial = attrs.initialPercentage / 100;
			margin = child.offsetLeft;

			angular.element($window).bind('resize', setDefaults);
			setDefaults();

			element.find('panel-control').on('click', function(event) {
				var classes = event.target.getAttribute('class');
				if (classes.indexOf('left') >= 0) {
					offset -= delta;
				} else if (classes.indexOf('right') >= 0) {
					offset += delta;
				}
				offset = Math.min(Math.max(offset, -margin-25), maxOffset+25);
				angular.element(child).css('margin-left', -offset + 'px');
				$timeout(setOffset, 250);
			});

		}
	}
}]);

})();

// Source: select.js
// Alternative implementation of the <select> element using pure AngularJS

angular.module('bs-plus.select', ['ngSanitize'])
.directive('bspSelect', ['$window', '$compile', function($window, $compile) {
	return {
		restrict: 'E',
		transclude: true,
		templateUrl: 'select/bsp-select.tmpl.html',
		scope: {
			model: '=?ngModel',
			ngChange: '&'
		},
		controller: ['$scope', function($scope) {
			var self = this;
			$scope.isWorking = false;
			$scope.showDropdown = false;
			$scope.optionElements = [];

			$scope.renderButtonLabels = function() {
				return self.renderButtonLabels($scope.buttonLabels);
			};

			self.addCloseIcons = function(buttonLabels) {
				var k;
				for (k = 0; k < buttonLabels.length; k++) {
					if (angular.isDefined($scope.model[k])) {
						buttonLabels[k] += '<sup class="deselect btn btn-default" value="' + $scope.model[k] + '">&times;</sup>';
					}
				}
			};

			self.renderButtonLabels = function(buttonLabels) {
				var k;
				if (buttonLabels.length > 0) {
					buttonLabels = angular.copy(buttonLabels);
					if (self.deselectable) {
						self.addCloseIcons(buttonLabels);
					}
					return buttonLabels.join('<span class=sep></span>');
				}
				return $scope.emptyLabel;
			};

			self.addOptionElement = function(element) {
				$scope.optionElements.push(element);
			};

			self.deselectAll = function() {
				angular.forEach($scope.optionElements, function(elem) {
					elem.removeClass('active');
				});
			};

			self.startWorking = function() {
				$scope.isWorking = true;
			};

			self.stopWorking = function() {
				$scope.ngChange();
				// test with this: $scope.$apply($scope.ngChange);
				$scope.isWorking = false;
			};

			self.selectOption = function(optionElement) {
				if (self.isMultiple) {
					optionElement.toggleClass('active');
				} else {
					self.deselectAll();
					optionElement.addClass('active');
				}
				self.syncButton(true);
			};

			self.syncButton = function(changeModel) {
				// from the dropdown box settings, build a button whose content reflects the current state
				var values = [];
				$scope.buttonLabels = [];
				angular.forEach($scope.optionElements, function(element) {
					var acronym, value;
					if (element.hasClass('active')) {
						// add option's subelement <acronym>...</acronym> to the list of selected elements
						acronym = element.find('acronym');
						if (acronym.length > 0) {
							$scope.buttonLabels.push(acronym.html());
						} else {
							// otherwise, take the whole element's content
							$scope.buttonLabels.push(element.html());
						}
						value = element.attr('value');
						if (angular.isDefined(value)) {
							values.push(value);
						}
					}
				});
				$scope.cssClasses = $scope.isDisabled ? {disabled: 'disabled'} : {};
				if (changeModel) {
					$scope.model = self.isMultiple ? values : values.join();
				}
			};

			self.syncModel = function() {
				// from the model settings, set the dropdown box and the button state
				if (self.isMultiple) {
					angular.forEach($scope.optionElements, function(elem) {
						elem.removeClass('active');
					});
					angular.forEach($scope.optionElements, function(elem) {
						if ($scope.model.indexOf(elem.attr('value')) >= 0) {
							elem.addClass('active');
						}
					});
				} else {
					angular.forEach($scope.optionElements, function(elem) {
						elem.removeClass('active');
						if (elem.attr('value') === $scope.model) {
							elem.addClass('active');
						}
					});
				}
				self.syncButton(false);
			};

			self.closeDropdown = function() {
				$scope.showDropdown = false;
			};

			self.toggleDropdown = function($event) {
				var value, index;
				if ($event.target.tagName === 'SUP') {
					self.startWorking();
					value = angular.element($event.target).attr('value');
					angular.forEach($scope.optionElements, function(elem) {
						if (elem.attr('value') === value) {
							elem.removeClass('active');
							index = $scope.model.indexOf(value);
							if (index >= 0) {
								$scope.model.splice(index, 1);
							}
						}
					});
					self.syncButton(true);
					self.stopWorking();
				} else {
					$scope.showDropdown = !$scope.isDisabled && !$scope.showDropdown;
				}
			};

			$scope.toggleDropdown = function($event) {
				$event.stopPropagation();
				self.toggleDropdown($event);
			};

			$scope.deselectAll = function() {
				self.deselectAll();
				self.closeDropdown();
				self.syncButton(true);
			};

			$scope.filterOptions = function() {
				var lcSearchString = angular.lowercase($scope.searchString);
				if (lcSearchString.length > 0) {
					angular.forEach($scope.optionElements, function(elem) {
						var text = elem.clone();
						text.find('abbr').remove(); // since the <abbr> element doesn't show up in the dropdown box
						if (angular.lowercase(text.text()).search(lcSearchString) >= 0) {
							elem.css('display', 'block');
						} else {
							elem.css('display', 'none');
						}
					});
				} else {
					angular.forEach($scope.optionElements, function(elem) {
						elem.css('display', 'block');
					});
				}
			};

			$scope.resetFilter = function() {
				$scope.searchString = '';
				$scope.filterOptions();
			};
		}],
		controllerAs: 'self',
		link: function(scope, element, attrs, controller, transclude) {
			function addFilterInputElement() {
				// add a search field to filter options
				var filterElem;
				if (!scope.filterPlaceholder)
					return;
				filterElem = $compile(
					'<div class="filter">' +
						'<input placeholder="{{ filterPlaceholder }}" type="text" ng-change="filterOptions()" ng-model="searchString">' +
					'<button type="button" class="button reset" ng-click="resetFilter()">&times;</button>' + 
					'</div>')(scope);
				angular.forEach(element.find('div'), function(divElem) {
					if (divElem.attributes.hasOwnProperty('ng-transclude')) {
						angular.element(divElem).prepend(filterElem);
					}
				});
			}
			// need some help on transclude. Otherwise the filterElem has to be added to the DOM manually, see above.
			controller.isMultiple = attrs.hasOwnProperty('multiple');
			controller.isRequired = attrs.hasOwnProperty('required');
			controller.deselectable = controller.isMultiple && attrs.hasOwnProperty('deselectable');
			scope.name = attrs.hasOwnProperty('name') ? attrs.name : null;
			scope.emptyLabel = attrs.hasOwnProperty('emptyLabel') ? attrs.emptyLabel : '---';
			scope.model = controller.isMultiple ? [] : '';
			scope.isDisabled = attrs.hasOwnProperty('disabled');
			scope.selectNone = (attrs.hasOwnProperty('selNone') && (!controller.isRequired || controller.isMultiple)) ? attrs.selNone : false;
			scope.filterPlaceholder = attrs.hasOwnProperty('filter') ? attrs.filter : false;
			addFilterInputElement();
			scope.$watch('model', function(newValue, oldValue) {
				if (!scope.isWorking && !angular.equals(newValue, oldValue)) {
					controller.syncModel();
				}
			});
			controller.syncButton(true);
			angular.element($window).on('click', function() {
				controller.closeDropdown();
				scope.$apply();
			});
		}
	};
}])
.directive('bspOptgroup', function() {
	return {
		require: ['^bspSelect', 'bspOptgroup'],
		restrict: 'E',
		scope: {},
		controller: ["$scope", function($scope) {
			this.optGroupElements = [];

			this.addOptionElement = function(element) {
				this.optGroupElements.push(element);
				this.selectCtrl.addOptionElement(element);
			};

			this.selectOption = function(optionElement) {
				if (this.isSingle) {
					// deactivate all options in the same optgroup
					angular.forEach(this.optGroupElements, function(elem) {
						if (angular.equals(optionElement, elem)) {
							elem.toggleClass('active');
						} else {
							elem.removeClass('active');
						}
					});
					this.selectCtrl.syncButton(true);
				} else {
					this.selectCtrl.selectOption(optionElement);
				}
			};

			this.selectGroup = function(optionElement) {
				if (this.isSelectable) {
					var allActive = this.allActive = !this.allActive;
					// activate all options in the same optgroup
					angular.forEach(this.optGroupElements, function(elem) {
						allActive ? elem.addClass('active') : elem.removeClass('active');
					});
					this.selectCtrl.syncButton(true);
				}
			};
		}],
		link: {
			pre: function(scope, element, attrs, controllers) {
				controllers[1].selectCtrl = controllers[0];
			},
			post: function(scope, element, attrs, controllers) {
				var controller = controllers[1];
				controller.isSingle = attrs.hasOwnProperty('single');
				controller.isSelectable = attrs.hasOwnProperty('selectable');
				controller.allActive = false;
				if (controller.isSelectable) {
					element.addClass('selectable');
				}
				element.on('click', function($event) {
					var optgroupElement = angular.element($event.target);
					controller.selectCtrl.startWorking();
					controller.selectGroup(optgroupElement);
					scope.$apply();
					controller.selectCtrl.stopWorking();
				});
			}
		}
	};
})
.directive('bspOption', function() {
	return {
		require: ['^bspSelect', '?^bspOptgroup'],
		restrict: 'E',
		scope: {},
		link: function(scope, element, attrs, controllers) {
			var selectCtrl = controllers[0],
				parentCtrl = angular.isDefined(controllers[1]) ? controllers[1] : controllers[0],
				isDisabled = attrs.hasOwnProperty('disabled');

			parentCtrl.addOptionElement(element);
			if (attrs.hasOwnProperty('selected')) {
				element.addClass('active');
			}
			if (isDisabled) {
				element.addClass('disabled');
			}
			element.on('click', function($event) {
				$event.stopPropagation();  // prevents to trigger wrapping handlers
				if (isDisabled)
					return;
				selectCtrl.startWorking();
				parentCtrl.selectOption(angular.element(this));
				if (!selectCtrl.isMultiple) {
					selectCtrl.closeDropdown();
				}
				scope.$apply();
				selectCtrl.stopWorking();
			});
		}
	};
});

(function(angular, undefined) {
})(window.angular);

})(window, document);
